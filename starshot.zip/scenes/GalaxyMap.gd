extends Control

func _ready() -> void:
	_draw_map()

func _draw_map() -> void:
	var list := $Scroll/StarList
	for c in list.get_children():
		c.queue_free()

	for s in GameState.systems:
		var sys_visible := false
		var first_pid:int = int(s.get("first_pid", 0))
		var last_pid:int  = int(s.get("last_pid", -1))
		for pid in range(first_pid, last_pid + 1):
			if GameState.is_unlocked(pid):
				sys_visible = true
				break
		if not sys_visible:
			break

		var star_box := HBoxContainer.new()
		star_box.add_theme_constant_override("separation", 12)
		list.add_child(star_box)

		var star_btn := Button.new()
		star_btn.text = "★ Sistema %d" % int(s.get("id", 0))
		star_btn.disabled = true
		star_box.add_child(star_btn)

		var planets_flow := HFlowContainer.new()
		planets_flow.custom_minimum_size = Vector2(0, 40)
		star_box.add_child(planets_flow)

		for pid in range(first_pid, last_pid + 1):
			if not GameState.is_unlocked(pid):
				if pid == GameState.highest_unlocked + 1:
					var locked := Button.new()
					locked.text = "[?]"
					locked.disabled = true
					locked.modulate = Color(1,1,1,0.4)
					planets_flow.add_child(locked)
				break

			var b := Button.new()
			b.text = "P%03d" % pid
			b.tooltip_text = "Req: %d pts" % GameState.required_score_for(pid)
			b.pressed.connect(_on_planet_pressed.bind(pid))
			planets_flow.add_child(b)

func _on_planet_pressed(pid:int) -> void:
	if not GameState.is_unlocked(pid):
		return
	GameState.current_planet = pid
	get_tree().change_scene_to_file("res://scenes/Shooter.tscn")
