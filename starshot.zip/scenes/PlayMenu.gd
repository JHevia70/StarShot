extends Control

func _ready() -> void:
	$VBox/NewGameButton.pressed.connect(_on_new)
	$VBox/ContinueButton.pressed.connect(_on_continue)
	$VBox/BackButton.pressed.connect(_on_back)
	$VBox/ContinueButton.disabled = not GameState.has_save()
	if $VBox/ContinueButton.disabled:
		$VBox/ContinueButton.modulate = Color(1,1,1,0.5)

func _on_new() -> void:
	GameState.new_game()
	get_tree().change_scene_to_file("res://scenes/GalaxyMap.tscn")

func _on_continue() -> void:
	if GameState.has_save():
		GameState.continue_game()
		get_tree().change_scene_to_file("res://scenes/GalaxyMap.tscn")

func _on_back() -> void:
	get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")
